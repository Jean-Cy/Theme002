import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#app')





// const jsonAPI =
//       '[{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"},{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]';

//     console.log(jsonAPI);

//     console.log(JSON.parse(jsonAPI));

//     const dataParsed = JSON.parse(jsonAPI);

    // Création d'un tableau des starts uniquement
    // const startArray = [];
    // const endArray = [];
    // dataParsed.forEach((element) => {

    //   const DATE = new Date(element.start)
    //   const DATEJOUR = DATE.getDay();

    //   startArray.push(element.start);
    //   endArray.push(element.start);
    //   console.log(DATEJOUR)
    // });

    
    // // On peut utiliser SLICE pour récupérer les 5 derniers jours 
    // // (ou les N derniers jours si on veut pouvoir laisser le choix à l'utilisateur)
    // // On ne slice que 
    
    // const startArraySliced = startArray.slice(-5);
    // const endArraySliced = endArray.slice(-5);

  
    // console.log(startArray, endArray, startArraySliced, endArraySliced);


    // // Sur les regroupements avec tous les utilisateurs
    // // on peut pouvoir identifier le jour de travail le plus élevé
    // // et faire un graphe de bar pour chaque utilisateur

    // // Pour un regroupement on aurait qque chose du genre 

    // const user1 =
    //   '[{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"},{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]';
    // const user2 =
    //   '[{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"},{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]';
    // const twoUsers = [JSON.parse(user1),JSON.parse(user2)]

    // // CALCUL DES TOTAUX 

    // // On calcule pour chaque paire de end / start le nombre d'heures d'écart

    // // Méthode 

    // console.log(((new Date('2021-10-25T17:10:30.000Z')).getTime()-(new Date('2021-10-25T10:10:30.000Z')).getTime()))
    
    // const dayDifference = ((new Date('2021-10-25T17:10:30.000Z')).getTime()-(new Date('2021-10-25T10:10:30.000Z')).getTime());

    // const dayDifferenceConverted = (new Date(dayDifference)).getHours();
    // console.log(dayDifferenceConverted);

    // // Ensuite, on boucle sur chaque user et chaque paire pour ajouter les totaux à un tableau totaux
    
    // const totaux = [];
    // let difference = 0;
    // let userTotal = 0;

    // twoUsers.forEach((user)=>
    // {
    //       user.forEach(paire =>{
    //           difference = (new Date((new Date(paire.end)).getTime()-(new Date(paire.start)).getTime())).getHours();
    //           userTotal = userTotal + difference;
    //           difference = 0;
    //       })
    //     totaux.push({userName: user,total:userTotal});
    //     userTotal = 0;
    // }
    // );

    // console.log(totaux) // On se servirait ensuite de ce tableau user / usertotal 
    // // faire un graphe à Barres
    
    // // IDENTIFIER LE JOUR LE PLUS TRAVAILLÉ

    // //     const jsonAPIAllUsers ='[[{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]' '[{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]';
    // //             '[{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]';

    // // ]'

