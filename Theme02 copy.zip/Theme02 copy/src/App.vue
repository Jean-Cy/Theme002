<template>
  <div id="app">
    <Dashboard />

    <h2>AVEC DONNEES DYNAMIQUES</h2>

    <TestAPIRepartitionHeures />
    <TestAPIRepartitionSemaine />
    <TestAPIJourLePlusTravaille />

    <!-- Tests avec données dynamiques en haut et données en solide en bas -->
    <h2>AVEC DONNEES BRUTES</h2>
    <GraphRepartitionHeures
      v-bind:labels="[
        'Jean Dupont',
        'Daniel Georges',
        'Inès Lavie',
        'Ane Grenade',
        'Bob Lodan',
        'Jenny Bai',
      ]"
      v-bind:datas="[0.2, 1, 5, 2, 3, 2]"
    />
    <GraphJourLePlusTravaille />
    <GraphRepartitionSemaine />
    <TimeManagement />
  </div>
</template>

<script>
import Dashboard from "./components/Dashboard.vue";

import TestAPIRepartitionHeures from "./components/TestAPIRepartitionHeures.vue";
import TestAPIRepartitionSemaine from "./components/TestAPIRepartitionSemaine.vue";
import TestAPIJourLePlusTravaille from "./components/TestAPIJourLePlusTravaille.vue";

import GraphJourLePlusTravaille from "./components/GraphJourLePlusTravaille.vue";
import GraphRepartitionHeures from "./components/GraphRepartitionHeures.vue";
import GraphRepartitionSemaine from "./components/GraphRepartitionSemaine.vue";
import TimeManagement from "./components/TimeManagement.vue";

export default {
  name: "App",
  components: {
    Dashboard,
    TestAPIRepartitionSemaine,
    TestAPIRepartitionHeures,
    TestAPIJourLePlusTravaille,
    GraphJourLePlusTravaille,
    GraphRepartitionHeures,
    GraphRepartitionSemaine,
    TimeManagement,
  },
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
