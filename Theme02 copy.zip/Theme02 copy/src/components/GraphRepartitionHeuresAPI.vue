<script>
import { Bar } from "vue-chartjs";

export default {
  extends: Bar,
  props:{
      labels:Array,
      datas: Array,
  },
  mounted() {
    this.renderChart(
      {
        labels: this.labels,
        datasets: [
          {
            label: "Heures cumulées cette semaine par utilisateur (test DONNEES JSON)",
            backgroundColor: "#224870",
            data: this.datas,
          },
        ],
      },
      { responsive: true, maintainAspectRatio: false }
    );
  },
};
</script>

