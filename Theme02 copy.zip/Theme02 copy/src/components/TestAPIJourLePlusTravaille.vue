<template>
  <!-- Ce compose a 2 vocations :
  1/ Il transmet les données au composant graphique, ce sera ici qu'on fera l'appel à l'API 
  2/ Il appelle le composant graphique avec ces données-->
  <div class="container">
    <GraphJourLePlusTravailleAPI v-if="loaded" v-bind:datas="datas" />
    <!-- v-if permet d'attendre le chargement des données de l'API
      Les v-bind permettent d'envoyer à notre composant autre chose qu'une simple chaîne de caractère.
      On pourrait aussi envoyer des options à notre composant si on voulait gérer une personnalisation du graphe. -->
  </div>
</template>

<script>
import GraphJourLePlusTravailleAPI from "./GraphJourLePlusTravailleAPI.vue";

export default {
  name: "LineChartContainer",
  components: { GraphJourLePlusTravailleAPI },

  data: () => ({
    loaded: false,
    datas: null,
  }),
  async mounted() {
    this.loaded = false;
    try {
      // Ici, on récupererait les données de l'API :
      //   const { userlist } = await fetch('/api/userlist')
      //   this.chartdata = userlist

      // Pour l'instant, on renvoit des données brutes pour afficher quelque chose.
      // Dans l'exemple on ne calcule pas encore la moyenne du service, mais seulement les heures de l'employé

      // Jeu de données

      const user1 = JSON.parse(
        '[{"start":"2021-10-20T10:10:30.000Z", "id":"1", "end":"2021-10-20T17:17:30.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"1", "end":"2021-10-25T17:17:30.000Z"},{"start":"2021-10-26T12:10:30.000Z", "id":"2", "end":"2021-10-26T13:17:30.000Z"},{"start":"2021-10-27T09:10:30.000Z", "id":"3", "end":"2021-10-27T16:16:45.000Z"},{"start":"2021-10-28T10:10:30.000Z", "id":"4", "end":"2021-10-28T17:16:30.000Z"},{"start":"2021-10-29T10:10:30.000Z", "id":"5", "end":"2021-10-29T18:16:30.000Z"},{"start":"2021-10-30T10:10:30.000Z", "id":"6", "end":"2021-10-30T17:16:20.000Z"},{"start":"2021-10-31T10:08:30.000Z", "id":"7", "end":"2021-10-31T16:12:30.000Z"}]'
      );

      const user2 = JSON.parse(
        '[{"start":"2021-10-20T09:10:30.000Z", "id":"1", "end":"2021-10-20T17:17:30.000Z"},{"start":"2021-10-25T09:10:30.000Z", "id":"1", "end":"2021-10-25T17:17:30.000Z"},{"start":"2021-10-26T12:10:30.000Z", "id":"2", "end":"2021-10-26T13:17:30.000Z"},{"start":"2021-10-27T09:10:30.000Z", "id":"3", "end":"2021-10-27T16:16:45.000Z"},{"start":"2021-10-28T10:10:30.000Z", "id":"4", "end":"2021-10-28T17:16:30.000Z"},{"start":"2021-10-29T10:10:30.000Z", "id":"5", "end":"2021-10-29T18:16:30.000Z"},{"start":"2021-10-30T10:10:30.000Z", "id":"6", "end":"2021-10-30T17:16:20.000Z"},{"start":"2021-10-31T10:08:30.000Z", "id":"7", "end":"2021-10-31T16:12:30.000Z"}]'
      );

      const users = [user1, user2];
      const bilanSemaine = [];

      // Même principe que pour la répartion sur la semaine d'un utilisateur. La principale différence est que l'on va boucler sur tous les utilisateurs, et ajouter tous leurs totaux.
      const currentDay = new Date();
      currentDay.setDate(25);
      currentDay.setMonth(9);
      console.log(currentDay);

      // On construit la semaine selon le jour d'aujourd'hui (ici on se place au 25 octobre)

      const currentWeek = [currentDay.getDate() - currentDay.getDay() + 1];

      for (let i = 0; i < 6; i++) {
        currentWeek[i + 1] = currentWeek[i] + 1;
      }

      // Ensuite on boucle sur chaque utilisateur et ses données pour matcher le jour actuel avec celui de la semaine.
      // (à adapter si le tableau n'est pas sliced, cas où il n'y aurait pas plus de 30 entrées dans un tableau sliced)
      users.forEach((user) => {
        user.forEach((day) => {
          const dayStart = new Date(day.start);
          const dayEnd = new Date(day.end);

          const checkDay = currentWeek.find(
            (day) => day === dayStart.getDate()
          ); // Permet de checker si le jour du badgeage correspond à un jour de la semaine actuelle

          // Si le check est OK, on calcule la différence entre le start / end pour obtenir le nb d'heures travaillé, et on le place dans un tableau correspondant à son jour dans la semaine

          if (
            checkDay &&
            bilanSemaine[currentWeek.indexOf(checkDay)] != undefined
          ) {
            bilanSemaine[currentWeek.indexOf(checkDay)] =
              bilanSemaine[currentWeek.indexOf(checkDay)] +
              new Date(dayEnd.getTime() - dayStart.getTime()).getHours();
          }
          if (
            checkDay &&
            bilanSemaine[currentWeek.indexOf(checkDay)] === undefined
          ) {
            bilanSemaine[currentWeek.indexOf(checkDay)] = new Date(
              dayEnd.getTime() - dayStart.getTime()
            ).getHours();
          }
          // Le bilan de la semaine est cette fois-ci partagé entre les utilisateurs.
        });
      });

      this.datas = bilanSemaine;
      this.loaded = true;
    } catch (e) {
      console.error(e);
    }
  },
};
</script>

<style></style>
