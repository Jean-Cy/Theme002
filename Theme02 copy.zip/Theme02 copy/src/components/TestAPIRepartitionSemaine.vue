

<template>
  <!-- Ce compose a 2 vocations :
  1/ Il transmet les données au composant graphique, ce sera ici qu'on fera l'appel à l'API 
  2/ Il appelle le composant graphique avec ces données-->
  <div class="container">
      <GraphRepartitionSemaineAPI v-if="loaded" v-bind:userName= "userName" v-bind:datasUser="datasUser"/>
      <!-- v-if permet d'attendre le chargement des données de l'API
      Les v-bind permettent d'envoyer à notre composant autre chose qu'une simple chaîne de caractère.
      On pourrait aussi envoyer des options à notre composant si on voulait gérer une personnalisation du graphe. --> 
  </div>


</template>

<script>

import GraphRepartitionSemaineAPI from './GraphRepartitionSemaineAPI.vue'


export default {
  name: 'LineChartContainer',
  components: { GraphRepartitionSemaineAPI },

  data: () => ({
    loaded: false,
    userName: null,
    datasUser:null
  }),
  async mounted () {
    this.loaded = false
    try {

    // Ici, on récupererait les données de l'API :
    //   const { userlist } = await fetch('/api/userlist')
    //   this.chartdata = userlist

    // Pour l'instant, on renvoit des données brutes pour afficher quelque chose. 
    // Dans l'exemple on ne calcule pas encore la moyenne du service, mais seulement les heures de l'employé
  
    // Jeu de données 

    const user = JSON.parse('[{"start":"2021-10-20T10:10:30.000Z", "id":"1", "end":"2021-10-20T17:17:30.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"1", "end":"2021-10-25T17:17:30.000Z"},{"start":"2021-10-26T12:10:30.000Z", "id":"2", "end":"2021-10-26T13:17:30.000Z"},{"start":"2021-10-27T09:10:30.000Z", "id":"3", "end":"2021-10-27T16:16:45.000Z"},{"start":"2021-10-28T10:10:30.000Z", "id":"4", "end":"2021-10-28T17:16:30.000Z"},{"start":"2021-10-29T10:10:30.000Z", "id":"5", "end":"2021-10-29T18:16:30.000Z"},{"start":"2021-10-30T10:10:30.000Z", "id":"6", "end":"2021-10-30T17:16:20.000Z"},{"start":"2021-10-31T10:08:30.000Z", "id":"7", "end":"2021-10-31T16:12:30.000Z"}]');
    const bilanSemaine = [];
  // On boucle sur l'utilisateur pour récupérer les données des jours de la semaine actuel.
  // (en l'occurence notre utilisateur a travaillé tous les jours de la semaine du 25 octobre)

  // On pourra Slice le tableau sur les 7 derniers éléments pour éviter de traiter toute la donnée si ce n'est que la plus récente
  // semaine qui nous intéresse 

  // On utiliserait la date d'aujourd'hui pour créer la semaine en data, pour l'exemple on fixe la date actuelle au 26 octobre
 // const currentDay = new Date();

   const currentDay = new Date()
   currentDay.setDate(25);
   currentDay.setMonth(9);
   console.log(currentDay)

  // On construit la semaine selon le jour d'aujourd'hui

  const currentWeek = [currentDay.getDate()-currentDay.getDay()+1];

  for (let i = 0;i<6;i++) { 
          currentWeek[i+1] = currentWeek[i]+1;
  }

  // Ensuite on boucle sur les données de l'utilisateur pour matcher le jour actuel avec celui de la semaine.
  // (à adapter si le tableau n'est pas sliced, cas où il n'y aurait pas plus de 30 entrées dans un tableau sliced)

    user.forEach((day)=>
    {
      const dayStart = new Date(day.start);
      const dayEnd = new Date(day.end);

      const checkDay = currentWeek.find(day => day === dayStart.getDate()) // Permet de checker si le jour du badgeage correspond à un jour de la semaine actuelle
      
      // Si le check est OK, on calcule la différence entre le start / end pour obtenir le nb d'heures travaillé, et on le place dans un tableau correspondant à son jour dans la semaine

      if(checkDay){
        bilanSemaine[currentWeek.indexOf(checkDay)] = (new Date(dayEnd.getTime()-dayStart.getTime())).getHours();
      }

    })


    // console.log("*******");
    // console.log(bilanSemaine);
    // console.log("*******");

    this.userName = "Nelson Roy";
    this.datasUser = bilanSemaine;

      this.loaded = true
    } catch (e) {
      console.error(e)
    }
  }
}
</script>

<style>

</style>
