<script>
import { Radar } from "vue-chartjs";

export default {
  extends: Radar,
  props:{
      datas: Array,
  },
  mounted() {
    this.renderChart(
      {
        labels: [
          "Lundi",
          "Mardi",
          "Mercredi",
          "Jeudi",
          "Vendredi",
          "Samedi",
          "Dimanche",
        ],
        datasets: [
          // {
          //   label: "My First dataset",
          //   backgroundColor: "rgba(179,181,198,0.2)",
          //   borderColor: "rgba(179,181,198,1)",
          //   pointBackgroundColor: "rgba(179,181,198,1)",
          //   pointBorderColor: "#fff",
          //   pointHoverBackgroundColor: "#fff",
          //   pointHoverBorderColor: "rgba(179,181,198,1)",
          //   data: [65, 59, 90, 81, 56, 55, 40],
          // },
          {
            label: "Jour les plus travaillés",
            backgroundColor: "#224870",
            borderColor: "rgba(255,99,132,1)",
            pointBackgroundColor: "rgba(255,99,132,1)",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "rgba(255,99,132,1)",
            data: this.datas,
          },
        ],
      },
      { responsive: true, maintainAspectRatio: false }
    );
  },
};
</script>
