

<template>
  <!-- Ce compose a 2 vocations :
  1/ Il transmet les données au composant graphique, ce sera ici qu'on fera l'appel à l'API 
  2/ Il appelle le composant graphique avec ces données-->
  <div class="container">
      <GraphRepartitionHeuresAPI v-if="loaded" v-bind:labels= "labels" v-bind:datas="datas"/>
      <!-- v-if permet d'attendre le chargement des données de l'API
      Les v-bind permettent d'envoyer à notre composant autre chose qu'une simple chaîne de caractère.
      On pourrait aussi envoyer des options à notre composant si on voulait gérer une personnalisation du graphe. --> 
  </div>


</template>

<script>

import GraphRepartitionHeuresAPI from './GraphRepartitionHeuresAPI.vue'


export default {
  name: 'LineChartContainer',
  components: { GraphRepartitionHeuresAPI },

  data: () => ({
    loaded: false,
    labels: null,
    datas:null
  }),
  async mounted () {
    this.loaded = false
    try {

    // Ici, on récupererait les données de l'API :
    //   const { userlist } = await fetch('/api/userlist')
    //   this.chartdata = userlist

    // Pour l'instant, on renvoit des données brutes pour afficher quelque chose. 
    // On va prendre l'exemple avec deux utilisateurs.
    
    // Jeu de données 1 
    // const user1 = JSON.parse('[{"start":"2021-10-25T10:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"},{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]');
    // const user2 = JSON.parse('[{"start":"2021-10-25T11:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"},{"start":"2021-10-25T23:10:30.000Z","end":"2021-10-25T23:17:30.000Z"},{"start":"2021-10-26T23:09:30.000Z","end":"2021-10-26T23:18:30.000Z"},{"start":"2021-10-27T23:10:30.000Z","end":"2021-10-27T23:16:30.000Z"},{"start":"2021-10-28T23:10:30.000Z","end":"2021-10-28T23:15:00.000Z"},{"start":"2021-10-29T23:10:00.000Z","end":"2021-10-29T23:17:00.000Z"}]');
   
    // Jeu de données 2


    const user1 = JSON.parse('[{"start":"2021-10-25T10:10:30.000Z", "id":"1", "end":"2021-10-25T17:17:30.000Z"},{"start":"2021-10-25T12:10:30.000Z", "id":"2", "end":"2021-10-25T13:17:30.000Z"},{"start":"2021-10-25T09:10:30.000Z", "id":"3", "end":"2021-10-25T16:16:45.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"4", "end":"2021-10-25T17:16:30.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"5", "end":"2021-10-25T18:16:30.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"6", "end":"2021-10-25T17:16:20.000Z"},{"start":"2021-10-25T10:08:30.000Z", "id":"7", "end":"2021-10-25T16:12:30.000Z"}]');
    const user2 = JSON.parse('[{"start":"2021-10-25T15:10:30.000Z", "id":"1", "end":"2021-10-25T23:20:30.000Z"},{"start":"2021-10-25T06:10:30.000Z", "id":"2", "end":"2021-10-25T12:17:30.000Z"},{"start":"2021-10-25T09:10:30.000Z", "id":"3", "end":"2021-10-25T15:16:45.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"4", "end":"2021-10-25T18:16:30.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"5", "end":"2021-10-25T19:16:30.000Z"},{"start":"2021-10-25T10:10:30.000Z", "id":"6", "end":"2021-10-25T15:16:20.000Z"},{"start":"2021-10-25T10:08:30.000Z", "id":"7", "end":"2021-10-25T16:12:30.000Z"}]');
   
   
   const twoUsers = [user1,user2];

    console.log(twoUsers);

    const totaux = [];
    let difference = 0;
    let userTotal = 0;
    // On boucle sur tous les utilisateurs, ici on en a deux, dans l'absolu on aurait un tableau d'utilisateurs.

    twoUsers.forEach((user)=>
    {
          user.forEach(paire =>{
              difference = (new Date((new Date(paire.end)).getTime()-(new Date(paire.start)).getTime())).getHours();
              // On calcule la différence entre chaque jour travaillé pour calculer le nombre d'heures quotidien

              userTotal = userTotal + difference;
              // Cela nous permet d'ajouter chaque nombre d'heures journaliers à un nombre d'heures total
              difference = 0;
          })

        totaux.push(userTotal);
        userTotal = 0;
    }
    );
    // console.log("*******");
    // console.log(totaux);
    // console.log("*******");

    
    totaux.push(1); // Bug : si je n'ai que 2 données dans mes totaux, il ne m'affiche que la 1ère à corriger

    this.labels =["Jean Dupont","Daniel Georges"];
    this.datas = totaux;

    // this.labels =["Jean Dupont","Daniel Georges","Inès Lavie","Ane Grenade","Bob Lodan","Jenny Bai",];
    // this.datas = [0.2,1,5,2,3,2];


      this.loaded = true
    } catch (e) {
      console.error(e)
    }
  }
}
</script>

<style>

</style>
